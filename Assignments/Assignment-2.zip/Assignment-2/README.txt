1. The code.txt is written in Python Language, and it stores the configurations in an simulation1.csv and simulation2.csv file in the 'Configs/Assignment-2' directory.

2. simulation1.csv contains the configurations after dt timestep for 3 seconds of animation of configuration 1.

3. simulation2.csv contains the configurations after dt timestep for 5 seconds of animation of configuration 2.

4. simulation1.mp4 is the animation file showing the movement of the robotic arm when it's initial configuration was all zero.

5. simulation2.mp4 is the animation file showing the movement of the robotic arm when it's initial configuration was all zero except joint 2 being -1 radian.