1. The code.txt is written in Python Language, and it stores the nodes of the path in path.csv in the 'Configs/Assignment-3' directory.

2. path.csv contains the nodes in order to reach end goal.

3. simulation.mp4 is the animation file showing the path of the A* Algorithm.

4. screenshot.png is the screenshot of the obstacles, nodes, edges, and A* path.